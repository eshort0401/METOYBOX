# Meteorological Toy Box (METOYBOX)

A collection of meteorological (and other) toy/analytic models. Some pedagogic content.